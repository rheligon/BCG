jQuery Form Validation
======================

The jQuery form validation plugin unifies the way to validate HTML forms using JavaScript.
It is a simple clientside library that will save you a lot of time when it comes to adding validation on your HTML form inputs or selects!

The jQuery form Validation plugin is released under the MIT License.

The complete documentation, demo and further instructions can be found at www.runningcoder.org

Documentation
======================

www.runningcoder.org/jqueryvalidation/documentation/

Demos
======================

www.runningcoder.org/jqueryvalidation/demo/

Patch Notes
======================

www.runningcoder.org/jqueryvalidation/version/
